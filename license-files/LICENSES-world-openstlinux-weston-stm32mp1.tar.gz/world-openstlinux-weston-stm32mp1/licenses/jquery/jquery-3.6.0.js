 * Copyright OpenJS Foundation and other contributors
 * Released under the MIT license
 * https://jquery.org/license
