See docs/license.rst
