 * Copyright(c) 2000 - 2018 Bill Fink.  All rights reserved.
 * Copyright(c) 2003 - 2018 Rob Scott.  All rights reserved.
 *
 * nuttcp is free, opensource software.  You can redistribute it and/or
 * modify it under the terms of Version 2 of the GNU General Public
 * License (GPL), as published by the GNU Project (http://www.gnu.org).
 * A copy of the license can also be found in the LICENSE file.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * Based on nttcp
 * Developed by Bill Fink, billfink@mindspring.com
 *          and Rob Scott, rob@hpcmo.hpc.mil
 * Latest version available at:
 *	http://nuttcp.net/nuttcp/beta/
 *
 * Test TCP connection.  Makes a connection on port 5000(ctl)/5101(data)
 * and transfers fabricated buffers or data copied from stdin.
 *
 * Run nuttcp with no arguments to get a usage statement
 *
 * Modified for operation under 4.2BSD, 18 Dec 84
 *      T.C. Slattery, USNA
 * Minor improvements, Mike Muuss and Terry Slattery, 16-Oct-85.
