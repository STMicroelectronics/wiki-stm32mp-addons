        'License :: OSI Approved :: Python Software Foundation License',
