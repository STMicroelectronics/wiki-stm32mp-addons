Otherwise you will get spurious failures in the non-strict policies (preferred,
interleave.)

See the manpages [`numactl.8`](https://linux.die.net/man/8/numactl) and
[`numa.3`](https://linux.die.net/man/3/numa) for details.

# License, Copyrights, Acknowledgements

`numactl` and the demo programs are under the GNU General Public License, v.2.

`libnuma` is under the GNU Lesser General Public License, v2.1.

The manpages are under the same license as the Linux manpages (see the files.)

