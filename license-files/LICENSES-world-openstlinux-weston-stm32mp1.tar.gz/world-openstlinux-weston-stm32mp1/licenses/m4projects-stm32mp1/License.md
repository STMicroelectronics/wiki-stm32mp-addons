| Component                       | License              | Copyright |
|:---------                       |:-------              |:----------|
| CMSIS                           | Apache License 2.0   | Copyright (c) 2009-2017 ARM Limited. All rights reserved. |
| STM32MP1xx CMSIS                | Apache License 2.0   | ARM Limited - STMicroelectronics |
| STM32MP1xx HAL                  | BSD-3-Clause         | STMicroelectronics |
| BSP STM32MP15xx_EVAL            | BSD-3-Clause         | STMicroelectronics |
| BSP STM32MP15xx_DISCO           | BSD-3-Clause         | STMicroelectronics |
| FreeRTOS kernel                 | MIT                  | Copyright (C) 2017 Amazon.com, Inc. or its affiliates |
| OpenAMP_libmetal                | BSD-3-Clause         | Xilinx Inc. and Contributors |
| OpenAMP_open-amp                | BSD-3-Clause         | Xilinx Inc. and Contributors |
| ST Projects                     | BSD-3-Clause         | STMicroelectronics |
| ResMgr_Utilities                | BSD-3-Clause         | STMicroelectronics |
