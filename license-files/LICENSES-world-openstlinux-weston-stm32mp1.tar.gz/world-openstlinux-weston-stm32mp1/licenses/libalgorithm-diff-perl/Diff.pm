Copyright (c) 2000-2002 Ned Konz.  All rights reserved.
This program is free software;
you can redistribute it and/or modify it under the same terms
as Perl itself.
