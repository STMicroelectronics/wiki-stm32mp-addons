The client applications (`optee_test/host/*`) are provided under the
[GPL-2.0](http://opensource.org/licenses/GPL-2.0) license.

The user TAs (`optee_test/ta/*`) are provided under the
[BSD 2-Clause](http://opensource.org/licenses/BSD-2-Clause) license.
