<!--
Copyright 2023 The Khronos Group Inc.
Copyright 2023 Valve Corporation
Copyright 2023 LunarG, Inc.

SPDX-License-Identifier: Apache-2.0
-->

Files in this repository fall under the `Apache-2.0` license.

Full license text of these licenses is available at https://opensource.org/licenses/Apache-2.0
