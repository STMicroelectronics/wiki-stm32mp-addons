 * (c) 2013 Damir Sultanov, http://fronteed.com
 * MIT Licensed
