/*
 * pxaregs - tool to display and modify PXA250's registers at runtime
 *
 * (c) Copyright 2002 by M&N Logistik-Lösungen Online GmbH
 * set under the GPLv2
 *
 * $Id: pxaregs.c,v 1.14 2003/11/12 13:14:43 schurig Exp $
 *
 * Please send patches to h.schurig, working at mn-logistik.de
 * - added fix from Bernhard Nemec
 * - i2c registers from Stefan Eletzhofer
*/
