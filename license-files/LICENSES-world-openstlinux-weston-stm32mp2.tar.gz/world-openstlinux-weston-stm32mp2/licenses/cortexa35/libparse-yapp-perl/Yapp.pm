=head1 COPYRIGHT

The Parse::Yapp module and its related modules and shell scripts are copyright:
Copyright © 1998, 1999, 2000, 2001, Francois Desarmenien.
Copyright © 2017 William N. Braswell, Jr.

You may use and distribute them under the terms of either
the GNU General Public License or the Artistic License,
as specified in the Perl README file.

If you use the "standalone parser" option so people don't need to install
Parse::Yapp on their systems in order to run you software, this copyright
noticed should be included in your software copyright too, and the copyright
notice in the embedded driver should be left untouched.
